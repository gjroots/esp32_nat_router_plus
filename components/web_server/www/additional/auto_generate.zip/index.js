process.stdout.write('\033c');
const zlib = require('zlib');
var fs = require('fs'),
    chalk = require('chalk'),
    htmlMinify = require('html-minifier').minify,
    crypto = require('crypto'),
    UglifyJS = require("uglify-js"),
    execSync = require('child_process').execSync,
    csso = require('csso'),
    rimraf = require('rimraf'),
    extension,
    file,
    jsStatus,
    htmlStatus,
    JSresult,
    dir = './output/';

console.log(chalk.cyanBright("╔═╗┌─┐┌─┐   ╔╗╔┌─┐┌┬┐ ╦═╗┌─┐┬ ┬┌┬┐┌─┐┬─┐ _|_ \n║╣ └─┐├─┘32─║║║├─┤ │  ╠╦╝│ ││ │ │ ├┤ ├┬┘  |  \n╚═╝└─┘┴     ╝╚╝┴ ┴ ┴  ╩╚═└─┘└─┘ ┴ └─┘┴└─\n"))

console.log(chalk.cyanBright('\nESP32-NAT Router +  Auto site generator (C) 2023 Jaya Satish ') + chalk.redBright(' www.github.com/gjroots\n\n'));
console.log(chalk.cyanBright('Thanks to  @samdenty/Wi-PWN\n\n'))
if (fs.existsSync(dir)) rimraf.sync(dir);
rimraf.sync("./html/Gemfile.lock");
fs.mkdirSync(dir)
fs.mkdirSync(dir + "gzip")

console.log(chalk.redBright('Building site...\n'));


try {
    execSync('jekyll build', {
        env: { JEKYLL_ENV: 'binary' },
        cwd: './html',
        stdio: 'inherit'
    });
    console.log('Jekyll build completed successfully');
} catch (error) {
    console.error(`Error: ${error.message}`);
}

console.log(chalk.redBright('Generating gzip files...\n'));


function byte(file) {
    let output = zlib.gzipSync(file);
    if (filename == "404") {
        filename = "error_404"
    }
    // console.log(filename)
    fs.writeFileSync(dir + "gzip/" + filename + "." + extension.toLowerCase() + ".gz", output);
    process.stdout.write(chalk.cyanBright(" - gzipped"));
}

fs.readdir(dir + 'html', function (err, items) {
    for (var i = 0; i < items.length; i++) {
        extension = items[i].split('.').pop().toUpperCase();
        filename = items[i].split('.')[0].toLowerCase();
        if (extension == "HTML") {
            var spacing = 20 - items[i].length;
            process.stdout.write(items[i] + Array(spacing).join(" "));
            file = fs.readFileSync(dir + '/html/' + items[i], "utf8");
            file = htmlMinify(file, { collapseBooleanAttributes: !0, collapseWhitespace: !0, html5: !0, minifyCSS: !0, minifyJS: !0, processConditionalComments: !0, removeAttributeQuotes: !0, removeComments: !0, removeEmptyAttributes: !0, removeOptionalTags: !0, removeRedundantAttributes: !0, removeScriptTypeAttributes: !0, removeStyleLinkTypeAttributes: !0, removeTagWhitespace: !0, sortAttributes: !0, sortClassName: !0, trimCustomFragments: !0, useShortDoctype: !0 });
            process.stdout.write(chalk.yellowBright(" - minified"));
            byte(file);
            process.stdout.write(chalk.greenBright(" - complete!\n"));
        } else if (extension == "CSS") {
            var spacing = 20 - items[i].length;
            process.stdout.write(items[i] + Array(spacing).join(" "));
            file = fs.readFileSync(dir + '/html/' + items[i], "utf8");
            file = csso.minify(file).css;
            process.stdout.write(chalk.yellowBright(" - minified"));
            byte(file);
            process.stdout.write(chalk.greenBright(" - complete!\n"));
        }
    }
    htmlStatus = true;
});

fs.readdir(dir + '/html/js', function (err, items) {
    for (var i = 0; i < items.length; i++) {
        extension = items[i].split('.').pop().toUpperCase();
        filename = items[i].split('.')[0].toLowerCase();
        if (extension == "JS") {
            var spacing = 20 - items[i].length;
            process.stdout.write(items[i] + Array(spacing).join(" "));
            file = fs.readFileSync(dir + '/html/js/' + items[i], "utf8");
            JSresult = UglifyJS.minify(file);
            if (JSresult.error) {
                console.error(JSresult.error);
            } else {
                process.stdout.write(chalk.yellowBright(" - minified"));
                byte(JSresult.code);
                process.stdout.write(chalk.greenBright(" - complete!\n"));
            }
        }
    }
    jsStatus = true;
});


var interval = setInterval(function () {
    if (htmlStatus === true && jsStatus === true) {
        clearInterval(interval);
        console.log(chalk.greenBright("\n----------------------Process compleate-----------------------\n") +
            chalk.yellowBright("\nPress any key to exit"));
        process.stdin.setRawMode(true);
        process.stdin.resume();
        process.stdin.on("data", function () {
            process.exit();
        });
    }
}, 1000);


