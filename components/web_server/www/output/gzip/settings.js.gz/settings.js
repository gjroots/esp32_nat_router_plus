var ssid = getE('ssid'),
	password = getE('password'),
	ent_username = getE('enterprise_username'),
	ent_identity = getE('enterprise_identity'),
	apSsid = getE('apSsid'),
	apPassword = getE('apPassword'),
	macAp = getE('macAp'),
	randMacAp = getE('randMacAp'),
	staticIP = getE('staticIP'),
	subnetMask = getE('subnetMask'),
	gateway = getE('gateway'),
	dnsIP = getE('dnsIp'),
	CustomDns = getE('CustomDns'),
	darkMode = getE('darkMode'),
	ledEnable = getE('useLed'),
	webServer = getE('webServer'),
	macFilter = getE('macFilter'),
	apIP = getE('apIP'),
	macContainer = getE('macContainer'),
	dnsIpContainer = getE('dnsIpContainer'),
	nextDnsUrlContainer = getE('nextDnsUrlContainer'),
	adminUsername = getE('adminUsername'),
	adminPassword = getE('adminPassword'),
	maxLoginAttempts = getE('maxLoginAttempts'),
	blockingTimeMin = getE('blockingTimeMin'),
	res = '',
	checkboxChanges,
	inputChanges;

/* Add listeners to checkboxes */

randMacAp.addEventListener("change", switchMAC, false);
CustomDns.addEventListener("change", dns_Ip, false);

function getData() {
	getResponse('data/settings.json', function (responseText) {
		// try {
		// 	res = JSON.parse(responseText);
		// } catch (e) {
		// 	fadeIn();
		// 	notify("ERROR: Failed to load settings.json (E2)");
		// 	return;
		// }
		try {
			res = JSON.parse(responseText);
			log("RESPONSE  ~ ", res, true)
		} catch (err) {
			log("INVALID   ~ ", responseText, false)
			console.error(err)
			fadeIn();
			notify("ERROR: Failed to load settings.json (E2)");
			return
		}
		ssid.value = res.ssid;
		password.value = res.password;
		ent_username.value = res.entUsername;
		ent_identity.value = res.entIdentity;
		apSsid.value = res.apSsid;
		apPassword.value = res.apPassword;
		staticIP.value = res.staticIP;
		subnetMask.value = res.subnetMask;
		gateway.value = res.gateWay;
		macAp.value = res.macAp;
		apIP.value = res.apIP;
		dnsIP.value = res.dnsIP;
		randMacAp.checked = res.randMacAp;
		CustomDns.checked = res.CustomDns;
		ledEnable.checked = res.ledEnable;
		darkMode.checked = res.darkMode;
		webServer.checked = res.webServer;
		macFilter.checked = res.macFilterEnabled;
		adminUsername.value = res.authUsername;
		adminPassword.value = res.authPassword
		maxLoginAttempts.value = res.maxLoginAttempts
		blockingTimeMin.value = res.blockingTimeMin
		switchMAC();
		dns_Ip();
		// nextDNS();
		fadeIn();
	}, function () {
		notify("ERROR: Reset the settings  (E4)");
		fadeIn();
	});
}

function saveSettings() {
	showLoading();
	var url = 'data/settingsSave.json';
	url += "?ssid=" + encodeURI(ssid.value);
	url += "&password=" + encodeURI(password.value);
	url += "&ent_username=" + encodeURI(ent_username.value);
	url += "&ent_password=" + encodeURI(ent_identity.value);
	url += "&apSsid=" + encodeURI(apSsid.value);
	url += "&apPassword=" + encodeURI(apPassword.value);
	url += "&staticIP=" + staticIP.value;
	url += "&subnetMask=" + subnetMask.value;
	url += "&gateway=" + gateway.value;
	url += "&apIP=" + apIP.value;
	url += "&macAp=" + macAp.value;
	url += "&dnsIP=" + dnsIp.value;
	url += "&adminUsername=" + encodeURI(adminUsername.value);
	url += "&adminPassword=" + encodeURI(adminPassword.value);
	url += "&maxLoginAttempts=" + maxLoginAttempts.value;
	url += "&blockingTimeMin=" + blockingTimeMin.value;
	url += "&ledEnable=" + ledEnable.checked;
	url += "&randMacAp=" + randMacAp.checked;
	url += "&CustomDns=" + CustomDns.checked;
	url += "&darkMode=" + darkMode.checked;
	url += "&webServer=" + webServer.checked;
	url += "&macFilterEnable=" + macFilter.checked;


	getResponse(url, function (responseText) {
		if (responseText == "true") {
			getData();
			indicate(true);
			var uniqueKey = new Date();
			document.getElementById('darkStyle').setAttribute('href', 'dark.css?' + uniqueKey.getTime());
			defaultMetaColor();
			inputChanges = false;
			checkboxChanges = false;
		} else {
			indicate(false);
			notify("Failed to save settings! (E0)", 2000);
		}
	}, function () {
		getResponse('data/settings.json', function (responseText) {
			getData();
			indicate(true);
			var uniqueKey = new Date();
			document.getElementById('darkStyle').setAttribute('href', 'dark.css?' + uniqueKey.getTime());
			defaultMetaColor();
			inputChanges = false;
			checkboxChanges = false;
		}, function () {
			indicate(false);
			notify("ERROR: Failed to save settings! (E3)");
		});
	},null,"POST");
}

function resetSettings() {
	if (confirm("Are you sure reset to default settings?") == true) {
		showLoading();
		getResponse('data/settingsReset.json', function (responseText) {
			if (responseText == "true") {
				getData();
				indicate(true);
				restart(true);
			} else {
				notify("Failed to reset settings! (E1)", 2500);
				indicate(false);
			}
		}, function () {
			notify("ERROR: Reset the settings (E4)");
			indicate(false);
		});
	}
	inputChanges = false;
	checkboxChanges = false;
}


function switchMAC() {
	if (randMacAp.checked)
		macContainer.classList.add("disabled");
	else
		macContainer.classList.remove("disabled");
}
function dns_Ip() {
	if (CustomDns.checked) {
		dnsIpContainer.classList.remove("disabled");
	} else {
		dnsIpContainer.classList.add("disabled");
	}
}

getData();

/* Detect form changes and display popup if not saved */
var form = document.getElementById("settings");
form.addEventListener("input", function () {
	inputChanges = true;
});
form.addEventListener("change", function () {
	checkboxChanges = true;
}, false);

window.addEventListener("beforeunload", function (e) {
	if (inputChanges || checkboxChanges) {
		var confirmationMessage = 'All changes will be lost!';
		(e || window.event).returnValue = confirmationMessage;
		return confirmationMessage;
	}
});
